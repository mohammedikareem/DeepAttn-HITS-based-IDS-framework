from src.runner import main
import sys
if __name__ == '__main__':
    sys.argv = ['', '--datasets', 'cicids']
    main()
