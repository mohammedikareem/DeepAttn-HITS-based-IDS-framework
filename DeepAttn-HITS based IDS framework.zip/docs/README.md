# Docs

Put paper, diagrams, or extra notes here.
